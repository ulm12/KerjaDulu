package com.kelompok5.aplikasikerjadulu.Model;

public class ModelMenu {
    public String namaMenu;
    public int gambarMenu;

    public String getNamaMenu() {
        return namaMenu;
    }

    public void setNamaMenu(String namaMenu) {
        this.namaMenu = namaMenu;
    }

    public int getGambarMenu() {
        return gambarMenu;
    }

    public void setGambarMenu(int gambarMenu) {
        this.gambarMenu = gambarMenu;
    }
}
