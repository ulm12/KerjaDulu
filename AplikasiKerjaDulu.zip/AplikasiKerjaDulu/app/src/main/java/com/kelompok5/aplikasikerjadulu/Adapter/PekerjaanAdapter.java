package com.kelompok5.aplikasikerjadulu.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.kelompok5.aplikasikerjadulu.Activity.PekerjaanDetailActivity;
import com.kelompok5.aplikasikerjadulu.Model.ModelMenu;
import com.kelompok5.aplikasikerjadulu.Model.ModelPekerjaan;
import com.kelompok5.aplikasikerjadulu.R;

import java.util.ArrayList;
import java.util.List;

public class PekerjaanAdapter extends RecyclerView.Adapter<PekerjaanAdapter.ViewHolder> {
    private ArrayList<ModelPekerjaan> list;
    Context context;

    public PekerjaanAdapter(ArrayList<ModelPekerjaan> notesList) {
        this.list = notesList;
    }

    //----------------------------------

    @NonNull
    @Override
    public PekerjaanAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_pekerjaan_list, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull PekerjaanAdapter.ViewHolder holder, int position) {
        final ModelPekerjaan data = list.get(position);
        holder.mNama.setText(data.getNama());
        holder.mEmail.setText(data.getEmail());
        holder.mGaji.setText(data.getGaji());
        holder.mJenis.setText(data.getJenis());
        holder.itemView.setOnClickListener(view -> {
            Intent mIntent = new Intent(view.getContext(), PekerjaanDetailActivity.class);
            mIntent.putExtra("id", list.get(position).getId());
            mIntent.putExtra("nama", list.get(position).getNama());
            mIntent.putExtra("jenis", list.get(position).getJenis());
            mIntent.putExtra("deskripsi", list.get(position).getDeskripsi());
            mIntent.putExtra("gaji", list.get(position).getGaji());
            mIntent.putExtra("email", list.get(position).getEmail());
            view.getContext().startActivity(mIntent);
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView mNama,mJenis,mGaji,mEmail;
        public ViewHolder(View v) {
            super(v);
            mNama = v.findViewById(R.id.tv_namaPekerjaan);
            mJenis = v.findViewById(R.id.tv_jenisPekerjaan);
            mEmail = v.findViewById(R.id.tvAlamat);
            mGaji = v.findViewById(R.id.tv_gaji);
        }
    }

}
