package com.kelompok5.aplikasikerjadulu.Adapter;

public class LatihanAdapter {
}
