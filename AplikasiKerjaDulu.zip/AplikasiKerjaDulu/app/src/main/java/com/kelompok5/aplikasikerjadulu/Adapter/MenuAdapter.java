package com.kelompok5.aplikasikerjadulu.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.kelompok5.aplikasikerjadulu.Model.ModelMenu;
import com.kelompok5.aplikasikerjadulu.R;

import java.util.ArrayList;

public class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.viewHolder> {


    private ArrayList<ModelMenu> list;
    OnItemClickListener listener;
    Context context;

    public void setModelMenuArrayList(OnItemClickListener listener)
    {
        this.listener = listener;
    }

    public void setOnItemClickListener(OnItemClickListener listener){
        this.listener = listener;
    }
    public MenuAdapter(Context context, ArrayList<ModelMenu> list)
    {
        this.context = context;
        this.list = list;
    }

//--------------------------------------------------------------------------------------------------

    @NonNull
    @Override
    public MenuAdapter.viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v  = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_menu_list, parent,false);
        return new viewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MenuAdapter.viewHolder holder, int position) {
        final ModelMenu data = list.get(position);
        holder.imageMenu.setImageResource(data.getGambarMenu());
        holder.tvTitle.setText(data.getNamaMenu());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder {
        public CardView cvMenu;
        TextView tvTitle;
        ImageView imageMenu;
        public viewHolder(View v) {
            super(v);
            cvMenu = v.findViewById(R.id.cvMenu);
            tvTitle = v.findViewById(R.id.tvTitle);
            imageMenu = v.findViewById(R.id.imageMenu);

            v.setOnClickListener(view -> {
                int position = getAdapterPosition();
                if(listener != null && position != RecyclerView.NO_POSITION){
                    listener.onItemClick(list.get(position));
                }
            });
        }
    }

    public interface OnItemClickListener{
        void onItemClick(ModelMenu data);

    }
}
