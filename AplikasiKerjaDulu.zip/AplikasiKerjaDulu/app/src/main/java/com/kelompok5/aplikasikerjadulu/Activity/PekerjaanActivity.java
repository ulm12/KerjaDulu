package com.kelompok5.aplikasikerjadulu.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.kelompok5.aplikasikerjadulu.Adapter.MenuAdapter;
import com.kelompok5.aplikasikerjadulu.Adapter.PekerjaanAdapter;
import com.kelompok5.aplikasikerjadulu.Data.MenuData;
import com.kelompok5.aplikasikerjadulu.MainActivity;
import com.kelompok5.aplikasikerjadulu.Model.GetNote;
import com.kelompok5.aplikasikerjadulu.Model.ModelMenu;
import com.kelompok5.aplikasikerjadulu.Model.ModelPekerjaan;
import com.kelompok5.aplikasikerjadulu.R;
import com.kelompok5.aplikasikerjadulu.Rest.ApiClient;
import com.kelompok5.aplikasikerjadulu.Rest.ApiInterface;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PekerjaanActivity extends AppCompatActivity {

    ApiInterface mApiInterface;
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pekerjaan);

        mRecyclerView = (RecyclerView) findViewById(R.id.rvPekerjaan);
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mApiInterface = ApiClient.getClient().create(ApiInterface.class);

        showData();

    }

    public void showData() {
        Call<GetNote> HerosCall = mApiInterface.getPekerjaan("get_work");
        Log.d("Ini","Hero" + HerosCall.toString());
        HerosCall.enqueue(new Callback<GetNote>() {
            @Override
            public void onResponse(Call<GetNote> call, Response<GetNote>
                    response) {
                ArrayList<ModelPekerjaan> notesList = (ArrayList<ModelPekerjaan>) response.body().getListDataNotes();
                Log.d("Retrofit Get", "Jumlah data Notes: " +
                        notesList.get(0).getNama());
                mAdapter = new PekerjaanAdapter(notesList);
                mRecyclerView.setAdapter(mAdapter);

            }

            @Override
            public void onFailure(Call<GetNote> call, Throwable t) {
                Log.e("Retro Get", t.getMessage());
            }
        });

    }




}