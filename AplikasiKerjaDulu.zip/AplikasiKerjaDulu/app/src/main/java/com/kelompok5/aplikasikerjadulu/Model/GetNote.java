package com.kelompok5.aplikasikerjadulu.Model;

import android.util.Log;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetNote {
    @SerializedName("status")
    String status;
    @SerializedName("message")
    String message;
    @SerializedName("data")
    List<ModelPekerjaan> listDataNotes;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<ModelPekerjaan> getListDataNotes() {
        return listDataNotes;
    }

    public void setListDataNotes(List<ModelPekerjaan> listDataNotes) {
        this.listDataNotes = listDataNotes;
    }
}
