package com.kelompok5.aplikasikerjadulu.Data;

import com.kelompok5.aplikasikerjadulu.Model.ModelMenu;
import com.kelompok5.aplikasikerjadulu.R;

import java.util.ArrayList;

public class MenuData {
    private static String [] namaMenu = {"BelajarDulu","PekerjaanKu","LatihanKu","CVKu"};

    private static int  [] gambarMenu = {R.drawable.book, R.drawable.briefcase, R.drawable.test, R.drawable.cv};

    public static ArrayList<ModelMenu> getListData(){
        ArrayList<ModelMenu> list = new ArrayList<>();
        for(int position = 0; position < namaMenu.length; position++){
            ModelMenu modelMenu = new ModelMenu();
            modelMenu.namaMenu = namaMenu[position];
            modelMenu.gambarMenu = gambarMenu[position];
            list.add(modelMenu);
        }
        return list;
    }
}
