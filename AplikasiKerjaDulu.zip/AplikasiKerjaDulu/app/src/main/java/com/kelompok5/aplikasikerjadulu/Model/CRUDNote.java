package com.kelompok5.aplikasikerjadulu.Model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class CRUDNote {
    @SerializedName("status")
    String status;
    @SerializedName("message")
    String message;
    @SerializedName("data")
    ModelPekerjaan mNotes;

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public ModelPekerjaan getHeros() {
        return mNotes;
    }
    public void setHeros(ModelPekerjaan Notes) {
        mNotes = Notes;
    }
}
