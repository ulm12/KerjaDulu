package com.kelompok5.aplikasikerjadulu;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import com.kelompok5.aplikasikerjadulu.Activity.BelajarActivity;
import com.kelompok5.aplikasikerjadulu.Activity.CVActivity;
import com.kelompok5.aplikasikerjadulu.Activity.LatihanActivity;
import com.kelompok5.aplikasikerjadulu.Activity.PekerjaanActivity;
import com.kelompok5.aplikasikerjadulu.Adapter.MenuAdapter;
import com.kelompok5.aplikasikerjadulu.Data.MenuData;
import com.kelompok5.aplikasikerjadulu.Model.ModelMenu;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView rvMenu;
    ArrayList<ModelMenu> list = new ArrayList<>();
    private RecyclerView.LayoutManager mLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvMenu = findViewById(R.id.rvMenu);
        rvMenu.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);

        list.addAll(MenuData.getListData());
        show_List();
    }

    private void show_List(){
        //set how item will display in layout content
        rvMenu.setLayoutManager(new GridLayoutManager(this, 2, RecyclerView.VERTICAL,false));
        MenuAdapter menuAdapter = new MenuAdapter(this,list);
        rvMenu.setHasFixedSize(true);
        rvMenu.setAdapter(menuAdapter);

        menuAdapter.setOnItemClickListener(modelMenu -> {
            if (modelMenu.getNamaMenu().equals("BelajarDulu")) {
                Intent intent = new Intent(MainActivity.this, BelajarActivity.class);
                startActivity(intent);
            }else if(modelMenu.getNamaMenu().equals("PekerjaanKu")){
                Intent intent = new Intent(MainActivity.this, PekerjaanActivity.class);
                startActivity(intent);
            }
            else if(modelMenu.getNamaMenu().equals("LatihanKu")){
                Intent intent = new Intent(MainActivity.this, LatihanActivity.class);
                startActivity(intent);
            }
            else if(modelMenu.getNamaMenu().equals("CVKu")){
                Intent intent = new Intent(MainActivity.this, CVActivity.class);
                startActivity(intent);
            }

        });

    }


}