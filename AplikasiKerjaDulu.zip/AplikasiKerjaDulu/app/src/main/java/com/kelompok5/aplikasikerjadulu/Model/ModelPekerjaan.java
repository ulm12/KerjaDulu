package com.kelompok5.aplikasikerjadulu.Model;

import com.google.gson.annotations.SerializedName;

public class ModelPekerjaan {

    @SerializedName("id")
    public int id;
    @SerializedName("nama")
    public String nama;
    @SerializedName("jenis")
    public String jenis;
    @SerializedName("deskripsi")
    public String deskripsi;
    @SerializedName("gaji")
    public String gaji;
    @SerializedName("email")
    public String email;


    public ModelPekerjaan(int id, String nama, String jenis, String deskripsi, String gaji, String email) {
        this.id = id;
        this.nama = nama;
        this.jenis = jenis;
        this.deskripsi = deskripsi;
        this.gaji = gaji;
        this.email = email;
    }

    public int getId() {
        return id;
    }

    public String getNama() {
        return nama;
    }

    public String getJenis() {
        return jenis;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public String getGaji() {
        return gaji;
    }

    public String getEmail() {
        return email;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setJenis(String jenis) {
        this.jenis = jenis;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }

    public void setGaji(String gaji) {
        this.gaji = gaji;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
