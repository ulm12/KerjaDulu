package com.kelompok5.aplikasikerjadulu.Rest;

import com.kelompok5.aplikasikerjadulu.Model.GetNote;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiInterface {
    //Get Data
    @GET("function/andro/restapinote.php")
    Call<GetNote> getPekerjaan(@Query("function") String function);



}
