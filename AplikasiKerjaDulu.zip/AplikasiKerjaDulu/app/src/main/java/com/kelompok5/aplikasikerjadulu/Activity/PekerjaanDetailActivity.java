package com.kelompok5.aplikasikerjadulu.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.kelompok5.aplikasikerjadulu.Adapter.PekerjaanAdapter;
import com.kelompok5.aplikasikerjadulu.Model.GetNote;
import com.kelompok5.aplikasikerjadulu.Model.ModelPekerjaan;
import com.kelompok5.aplikasikerjadulu.R;
import com.kelompok5.aplikasikerjadulu.Rest.ApiClient;
import com.kelompok5.aplikasikerjadulu.Rest.ApiInterface;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PekerjaanDetailActivity extends AppCompatActivity {

    TextView rPekerjaan,detail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pekerjaan_detail);

        rPekerjaan = findViewById(R.id.tv_namaPerusahaan);
        detail = findViewById(R.id.tv_detail);

        showData();

    }

    public void showData() {

        Intent mIntent = getIntent();
        rPekerjaan.setText(mIntent.getStringExtra("nama"));
        detail.setText(mIntent.getStringExtra("deskripsi"));

    }
}