package com.kelompok5.aplikasikerjadulu.Rest;

public class Config {
    public static final String BASE_URL = "https://kerjaduluapk.000webhostapp.com/KerjaDulu/";
}
